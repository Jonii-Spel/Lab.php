<?php
    include("conexion.php");

    include("ABM/validar_form.php");

        if ( $nombreT && $apellidoT && $localidadT ){

        include("ABM/operacion_nuevo.php");

        }

    session_start();
    $usuario = $_SESSION['username'];
        
    if (!isset($usuario)) {
      header("location: home.php");
    }

?>


<!doctype html>
<html lang="es">

<head>
    <title>Nuevo Cliente</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="boostrap\css\bootstrap.min.css">
</head>

<body>


    <nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
        <li>
            <a href="index.php" class="btn btn-success">Volver</a>
        </li>
    </nav>


    <div class="jumbotron">
        <h1>Agregar Cliente</h1><br>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <div class="form-row">
                <div class="col-5">
                    <input type="text" class="form-control" placeholder="Nombre" name="nombre">
                    <span class="error" style="color : red"><?php echo $nombreErr;?></span>
                </div>
                <div class="col-5">
                    <input type="text" class="form-control" placeholder="Apellido" name="apellido">
                    <span class="error" style="color : red"> <?php echo $apellidoErr;?></span>
                </div>
                <div class="col-3">
                    <input type="text" class="form-control" placeholder="Localidad" name="localidad">
                    <span class="error" style="color : red"> <?php echo $localidadErr;?></span>
                </div>
            </div><br>
            <button class="btn btn-secondary" type="sumbit" name="sumbit" value="Sumbit">Aceptar</button>
        </form>
    </div>


  
</body>

</html>





