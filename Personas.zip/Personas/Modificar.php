<?php

    include("conexion.php");


    session_start();
    $usuario = $_SESSION['username'];

    if (!isset($usuario)) {
    header("location: home.php");
    }

?>

<!doctype html>
<html lang="es">

<head>
    <title>Modificar Cliente</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="boostrap\css\bootstrap.min.css">
</head>

<body>


    <nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
        <li>
            <a href="index.php" class="btn btn-success">Volver</a>
        </li>
    </nav>

    <?php
    include("conexion.php");

    $id=$_REQUEST['id'];

    $query = "SELECT * FROM clientes WHERE Id= '$id'";
    $resultado = $conexion->query($query);
    $mostrar = $resultado->fetch_assoc();
    
?>


    <div class="jumbotron">
        <h1>Modificar Cliente</h1><br>

        <form action="ABM/operacion_modificar.php?id=<?php echo $mostrar['Id']?>" method="POST">

            <div class="form-row">
                <div class="col-5">
                    <input type="text" class="form-control" required name="nombre"
                        value="<?php echo $mostrar['Nombre']; ?>">
                </div>
                <div class="col-5">
                    <input type="text" class="form-control" required name="apellido"
                        value="<?php echo $mostrar['Apellido']; ?>">
                </div>
                <div class="col-3">
                    <input type="text" class="form-control" required name="localidad"
                        value="<?php echo $mostrar['Localidad']; ?>">
                </div>
            </div><br>
            <button class="btn btn-secondary" type="sumbit" value="Aceptar">Aceptar</button>

        </form>
    </div>




</body>

</html>