<?php
   $conexion = new mysqli(
      "localhost:3308", "root", "", "registropersonas");
?>
