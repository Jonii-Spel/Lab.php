<?php
    include("../conexion.php");

    $id=$_REQUEST['id'];
    $nombre= $_POST['nombre'];
    $apellido= $_POST['apellido'];
    $localidad= $_POST['localidad'];

    $query= "UPDATE clientes SET Nombre= '$nombre', Apellido='$apellido', Localidad='$localidad' WHERE Id='$id'";

    $resultado= $conexion->query($query);

    if ($resultado) {
        header("Location: ../index.php");
    }
?>