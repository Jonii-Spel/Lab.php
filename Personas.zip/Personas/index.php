<?php
include("conexion.php");
session_start();
$usuario = $_SESSION['username'];

if (!isset($usuario)) {
  header("location: home.php");
}


$query = "SELECT * FROM clientes";
$resultado = $conexion->query($query);

?>

<!doctype html>
<html lang="es">

<head>
    <title>CRUD Personas</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="boostrap\css\bootstrap.min.css">
</head>


<body>

    <nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top justify-content-between">
        <div>

            <form class="form-inline" action="buscar_usuario.php" method="get">
                <input class="form-control mr-sm-2" type="text" id="busqueda" name="busqueda" placeholder="Buscar..">
                <button class="btn btn-success" value="Buscar" type="submit" id="busqueda">Buscar</button>
                <?php echo" - "?>
            </form>
        </div>
        <div>
            <a href="Nuevo.php" class="btn btn-success">Nuevo Cliente</a>
        </div>



        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav ml-auto">
                <li>
                    <a href="logica/salir.php">Salir</a>
                </li>
            </ul>
        </div>
    </nav>


    <div class="jumbotron">
        <h1>Personas CRUD</h1>
        <div>
            <table class="table table-dark table-hover">
                <thead>
                    <tr>
                        <th>Clientes</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>ID</td>
                        <td>Nombre</td>
                        <td>Apellido</td>
                        <td>Localidad</td>
                        <td colspan="2">Acciones</td>
                    </tr>
                </tbody>
                <?php
        while ($mostrar = mysqli_fetch_array($resultado)) {
        ?>

                <tr>
                    <td> <?php echo $mostrar['Id'] ?> </td>
                    <td><?php echo $mostrar['Nombre'] ?></td>
                    <td><?php echo $mostrar['Apellido'] ?></td>
                    <td><?php echo $mostrar['Localidad'] ?></td>
                    <td><a href="ABM/Eliminar.php?id=<?php echo $mostrar['Id'] ?>">Eliminar</a></td>
                    <td><a href="Modificar.php?id=<?php echo $mostrar['Id'] ?>">Modificar</a></td>
                </tr>

                <?php
        }
        ?>
            </table>
        </div>
    </div>


</body>

</html>