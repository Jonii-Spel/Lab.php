<?php

    $nombreErr = $apellidoErr =  $localidadErr = "";
    $nombre = $apellido = $localidad  = "";
    $nombreT = $apellidoT = $localidadT = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  if (empty($_POST["nombre"])) {
    $nombreErr = "Nombre es requerido";
  } else {
    $nombreT = true;
  }
  if (empty($_POST["apellido"])) {
    $apellidoErr = "Apellido es requerido";
  } else {
    $apellidoT = true;
  }
  if (empty($_POST["localidad"])) {
    $localidadErr = "Localidad es requerido";
  } else {
    $localidadT = true;
  }
    
}








    
?>