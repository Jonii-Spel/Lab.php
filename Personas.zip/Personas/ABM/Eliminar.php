<?php
    include("../conexion.php");

    $id=$_REQUEST['id'];

    $query= "DELETE FROM clientes WHERE Id='$id' ";

    $resultado= $conexion->query($query);

    if ($resultado) {
        header("Location: ../index.php");
    }else {
        echo "No se realizo";
    }
?>