<?php

    include("conexion.php");
    
    session_start();

    $logeoerror = $nombreErr = $Passerror ='';
    $nombreErr = $Passerror  = "";
    $nombreT = $PassT = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

  if (empty($_POST["username"])) {
    $nombreErr = "Nombre de usuario es requerido";
  } else {
    $nombreT = true;
  }
  if (empty($_POST["password"])) {
    $Passerror = "Contraseña es requerida";
  } else {
    $PassT = true;
  }
  
    $user = $_POST['username'];
    $pass = $_POST['password'];
    

    $query = "SELECT COUNT(*) as contar
    FROM usuarios_pass
    WHERE USUARIOS = '$user' AND PASSWORD = '$pass' ";

    $consulta = mysqli_query($conexion,$query);
    $array = mysqli_fetch_array($consulta);

    if ($array['contar'] > 0) {
        $_SESSION['username'] = $user;
        header("location: index.php");
    } else {

        if (!empty($user) && !empty($pass) )
        $logeoerror = 'Usuario no encontrado';
    }
}
?>