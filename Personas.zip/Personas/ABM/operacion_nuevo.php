<?php
    include("conexion.php");

    $nombre= $_POST['nombre'];
    $apellido= $_POST['apellido'];
    $localidad= $_POST['localidad'];

    if (empty($nombre) || empty($apellido) || empty($localidad)) {

        header("Location: ../Nuevo.php");
        
    } else {
        $query= "INSERT INTO clientes(Nombre, Apellido, Localidad) VALUES('$nombre','$apellido','$localidad')";

        $resultado= $conexion->query($query);

        if ($resultado) {
            header("Location: /labphp/Personas/index.php");
        }
    }

    
?>