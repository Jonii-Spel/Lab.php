<?php

include('logica\iniciarSesion.php');

if (isset($_SESSION['username'])) {
    
    header("location: index.php");
}

?>

<!doctype html>
<html lang="en">

<head>
    <title>Administrador</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="boostrap\css\bootstrap.min.css">
</head>

<body>


    <nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-top">
        <li>
            <a class="navbar-brand" href="">Home</a>
        </li>
    </nav>

    
    <div class="jumbotron">

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="POST">
        <span class="error" style="color : red"> <?php echo $logeoerror;?></span>
            <div class="form-group">
                <label>Usuario:</label>
                <input type="text" class="form-control" placeholder="Usuario.." name="username">
                <span class="error" style="color : red"> <?php echo $nombreErr;?></span>
            </div>
            <div class="form-group">
                <label for="pwd">Contraseña:</label>
                <input type="password" class="form-control" placeholder="*****" name="password">
                <span class="error" style="color : red"> <?php echo  $Passerror ;?></span>
            </div>
            <button type="submit" class="btn btn-primary" >Aceptar</button>
        </form>
    </div>
   
</body>

</html>